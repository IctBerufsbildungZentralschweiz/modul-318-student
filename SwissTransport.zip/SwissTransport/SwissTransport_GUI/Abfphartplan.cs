﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SwissTransport;
using System.Net.Mail;

namespace SwissTransport_GUI
{
    public partial class Abfahrtplan : Form
    {
        public StationBoardRoot stationboardroot;
        Transport myTransport = new Transport();
        Stations myStations = new Stations();

        public string station;
        private string bodycontentemail = "";
        
        private void EmailSender(string emailadresse, string bodycontent)
        {

            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress("m318jo@gmail.com");
            mail.To.Add(emailadresse);
            mail.Subject = "Ihr Fahrplan";
            mail.Body = bodycontent;

            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("m318jo@gmail.com", "abcmeg11");
            SmtpServer.EnableSsl = true;

            SmtpServer.Send(mail);

        }



        public void Combox(ComboBox comboBoxName)
        {
            Transport t = new Transport();

            if (!string.IsNullOrEmpty(comboBoxName.Text))
            {
                List<Station> stations = t.GetStationBoard(comboBoxName.Text).StationList;
                if (stations.Count > 0)
                {
                    comboBoxName.Items.Clear();
                    foreach (Station station in stations)
                    {
                        comboBoxName.Items.Add(station.Name);
                    }
                }
                comboBoxName.Text = "";
                comboBoxName.SelectedIndex = 0;
            }

        }



        public Abfahrtplan()
        {
            InitializeComponent();
        }

        private void btnReturnform_Click(object sender, EventArgs e)
        {
            var form1 = (Form1)Tag;
            form1.Show();
            Close();
        }

        private void btnAbfahrtSearch_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            Combox(cbAbfahrt);
            station = cbAbfahrt.Text;
            StationBoardRoot stationBoard = myTransport.GetStationBoard(station, "");
           

            dataGridView1.ColumnCount = 2;
            dataGridView1.Columns[0].Name = "Abfahrt";
            dataGridView1.Columns[1].Name = "Zielort";

            foreach (StationBoard board in stationBoard.Entries)
            {
                string[] cache = new string[2];
                cache[0] = board.Stop.Departure.ToString("dd.MM.yyy hh:mm");
                cache[1] = board.To;

                bodycontentemail += "Abfahrtszeit: " + cache[0] + " Zieldestination: " + board.To.ToString() + "\n\n";
                //MessageBox.Show("nach: " + board.To + ", " + board.Stop.Departure.ToString("dd.MM.yyy hh:mm") + " Operated by: " + board.Operator);

                
                dataGridView1.Rows.Add(cache);

                
            }

        }




        private void btnEmail_Click(object sender, EventArgs e)
        {

            EmailSender(txtEmail.Text, bodycontentemail);

        }
    }
}
