﻿namespace SwissTransport_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblStart = new System.Windows.Forms.Label();
            this.lblZiel = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cbStart = new System.Windows.Forms.ComboBox();
            this.cbZiel = new System.Windows.Forms.ComboBox();
            this.btnZiel = new System.Windows.Forms.Button();
            this.btnVerbindung = new System.Windows.Forms.Button();
            this.dgvStationboard = new System.Windows.Forms.DataGridView();
            this.btnForm2 = new System.Windows.Forms.Button();
            this.transportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.transportBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStationboard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transportBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transportBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblStart
            // 
            this.lblStart.AutoSize = true;
            this.lblStart.Location = new System.Drawing.Point(23, 23);
            this.lblStart.Margin = new System.Windows.Forms.Padding(0);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(38, 17);
            this.lblStart.TabIndex = 2;
            this.lblStart.Text = "Start";
            // 
            // lblZiel
            // 
            this.lblZiel.AutoSize = true;
            this.lblZiel.Location = new System.Drawing.Point(23, 84);
            this.lblZiel.Margin = new System.Windows.Forms.Padding(0);
            this.lblZiel.Name = "lblZiel";
            this.lblZiel.Size = new System.Drawing.Size(31, 17);
            this.lblZiel.TabIndex = 3;
            this.lblZiel.Text = "Ziel";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(245, 37);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(112, 30);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Suchen";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cbStart
            // 
            this.cbStart.FormattingEnabled = true;
            this.cbStart.Location = new System.Drawing.Point(26, 43);
            this.cbStart.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.cbStart.Name = "cbStart";
            this.cbStart.Size = new System.Drawing.Size(152, 24);
            this.cbStart.TabIndex = 6;
            // 
            // cbZiel
            // 
            this.cbZiel.FormattingEnabled = true;
            this.cbZiel.Location = new System.Drawing.Point(26, 109);
            this.cbZiel.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.cbZiel.Name = "cbZiel";
            this.cbZiel.Size = new System.Drawing.Size(152, 24);
            this.cbZiel.TabIndex = 7;
            // 
            // btnZiel
            // 
            this.btnZiel.Location = new System.Drawing.Point(245, 100);
            this.btnZiel.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.btnZiel.Name = "btnZiel";
            this.btnZiel.Size = new System.Drawing.Size(112, 40);
            this.btnZiel.TabIndex = 8;
            this.btnZiel.Text = "Suchen";
            this.btnZiel.UseVisualStyleBackColor = true;
            this.btnZiel.Click += new System.EventHandler(this.btnZiel_Click);
            // 
            // btnVerbindung
            // 
            this.btnVerbindung.Location = new System.Drawing.Point(454, 292);
            this.btnVerbindung.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.btnVerbindung.Name = "btnVerbindung";
            this.btnVerbindung.Size = new System.Drawing.Size(170, 55);
            this.btnVerbindung.TabIndex = 9;
            this.btnVerbindung.Text = "Verbindungen Suchen";
            this.btnVerbindung.UseVisualStyleBackColor = true;
            this.btnVerbindung.Click += new System.EventHandler(this.btnVerbindung_Click);
            // 
            // dgvStationboard
            // 
            this.dgvStationboard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStationboard.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgvStationboard.Location = new System.Drawing.Point(9, 146);
            this.dgvStationboard.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.dgvStationboard.MultiSelect = false;
            this.dgvStationboard.Name = "dgvStationboard";
            this.dgvStationboard.ReadOnly = true;
            this.dgvStationboard.RowHeadersVisible = false;
            this.dgvStationboard.RowTemplate.Height = 24;
            this.dgvStationboard.Size = new System.Drawing.Size(429, 341);
            this.dgvStationboard.TabIndex = 10;
            // 
            // btnForm2
            // 
            this.btnForm2.Location = new System.Drawing.Point(460, 12);
            this.btnForm2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.btnForm2.Name = "btnForm2";
            this.btnForm2.Size = new System.Drawing.Size(173, 56);
            this.btnForm2.TabIndex = 11;
            this.btnForm2.Text = "Abfahrt ÖV";
            this.btnForm2.UseVisualStyleBackColor = true;
            this.btnForm2.Click += new System.EventHandler(this.btnForm2_Click);
            // 
            // transportBindingSource
            // 
            this.transportBindingSource.DataSource = typeof(SwissTransport.Transport);
            // 
            // transportBindingSource1
            // 
            this.transportBindingSource1.DataSource = typeof(SwissTransport.Transport);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 499);
            this.Controls.Add(this.btnForm2);
            this.Controls.Add(this.dgvStationboard);
            this.Controls.Add(this.btnVerbindung);
            this.Controls.Add(this.btnZiel);
            this.Controls.Add(this.cbZiel);
            this.Controls.Add(this.cbStart);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblZiel);
            this.Controls.Add(this.lblStart);
            this.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStationboard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transportBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transportBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblStart;
        private System.Windows.Forms.Label lblZiel;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ComboBox cbStart;
        private System.Windows.Forms.ComboBox cbZiel;
        private System.Windows.Forms.Button btnZiel;
        private System.Windows.Forms.Button btnVerbindung;
        private System.Windows.Forms.BindingSource transportBindingSource;
        private System.Windows.Forms.BindingSource transportBindingSource1;
        private System.Windows.Forms.DataGridView dgvStationboard;
        private System.Windows.Forms.Button btnForm2;
    }
}

