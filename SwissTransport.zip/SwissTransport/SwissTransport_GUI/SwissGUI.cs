﻿using SwissTransport;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SwissTransport_GUI
{
    public partial class Form1 : Form
    {

        Transport myTransport = new Transport();
        Connections connections = new Connections();
        Stations myStation = new Stations();

        public Form1()
        {
            InitializeComponent();
        }
       
        
            public void Combox(ComboBox comboBoxName)
            {
                Transport t = new Transport();

                if (!string.IsNullOrEmpty(comboBoxName.Text))
                {
                    List<Station> stations = t.GetStationBoard(comboBoxName.Text).StationList;
                    if (stations.Count > 0)
                    {
                        comboBoxName.Items.Clear();
                        foreach (Station station in stations)
                        {
                            comboBoxName.Items.Add(station.Name);
                        }
                    }
                    comboBoxName.Text = "";
                    comboBoxName.SelectedIndex = 0;
                }

            }
        
        private void btnSearch_Click(object sender, EventArgs e)
        {
            Combox(cbStart);
        }

        private void btnZiel_Click(object sender, EventArgs e)
        {
            Combox(cbZiel);
        }

        private void btnVerbindung_Click(object sender, EventArgs e)
        {
            List<Connection> connections = myTransport.GetConnections(cbStart.SelectedItem.ToString(), cbZiel.SelectedItem.ToString()).ConnectionList;
            connections.ForEach(delegate (Connection connection)
           {


               dgvStationboard.ColumnCount = 5;
               dgvStationboard.Columns[0].Name = "Departure";
               dgvStationboard.Columns[1].Name = "Arrival";
               dgvStationboard.Columns[2].Name = "Platform";



               DateTime dep = new DateTime(1970, 1, 1, 0, 0, 0, 0);
               DateTime arr = new DateTime(1970, 1, 1, 0, 0, 0, 0);



               dep = dep.AddSeconds(Double.Parse(connection.From.DepartureTimestamp));
               arr = arr.AddSeconds(Double.Parse(connection.To.ArrivalTimestamp));
               dgvStationboard.Rows.Add(dep.Hour.ToString() + ":" + dep.Minute.ToString(), arr.Hour.ToString() + ":" + arr.Minute.ToString(), connection.To.Platform.ToString());


           });



        }

        private void btnForm2_Click(object sender, EventArgs e)
        {
            Abfahrtplan form2 = new Abfahrtplan();
            form2.Tag = this;
            form2.Show(this);
           
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms.Count == 0)
                Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }


}

